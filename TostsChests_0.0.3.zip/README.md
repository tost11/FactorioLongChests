# Tosts-Train-Chests
Adds wood steel and iron chests with sizes i*6*1
Ideal for use with LTN to offer and request stuff in multiple cargos